A classe a inspecionar é a classe EventManagerData. A classe EventManager apenas
serve de interface entre a lógica de comunicação (classes de comunicação do Servidor)
e a lógica de negócio (classe EventManagerData). As classes encontram-se comentadas de
acordo com a norma do Java Docs.

Para contexto, a classe EventManagerData gere a criação e manipulação de eventos e também
a criação dos utilizadores juntamente com a gestão da autênticação. É também esta classe
que tem os "getters" necessários para a visualização na interface gráfica móvel.