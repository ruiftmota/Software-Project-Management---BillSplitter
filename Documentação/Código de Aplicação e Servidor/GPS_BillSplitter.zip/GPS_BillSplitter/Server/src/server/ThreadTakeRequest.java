package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

import com.google.gson.Gson;

import server.events_manager.EventsManager;
import server.events_manager.event_manager_data.events_information.EnumActionResult;
import server.events_manager.event_manager_data.events_information.Event;
import server.events_manager.event_manager_data.requests.*;



    /**
     * 
     * <h1>Taking the client request!</h1>
     * This class takes care of reading the request from the client, 
     * checking the kind of request it is, invoking the respective EventManager
     * method, and sending the EventManager answer back to the client after
     * having it prepared
     * 
     * @author  Rui Mota
     * @version 1.0
     * @since   29-09-2019
    */
public class ThreadTakeRequest extends Thread
{
    private Socket socket;

    private EventsManager eventsManager;

    private ObjectOutputStream oOS;
    private ObjectInputStream oIS;




    public ThreadTakeRequest(Socket socket, EventsManager eventsManager){ 
        this.socket = socket; 
        this.eventsManager = eventsManager;
    }




    
    @Override
    public void run() 
    {
	    System.out.println("Client request taken");
        try 
        {
            oOS = new ObjectOutputStream(socket.getOutputStream());
            oIS = new ObjectInputStream(socket.getInputStream());


            String stringRequest = (String)oIS.readObject();
            //Request request = gson.fromJson(stringRequest, Request.class);

            Request request = deserializeRequest(stringRequest);

            EnumActionResult enumAnswer = EnumActionResult.CONNECTION_ERROR;
            
            if(request instanceof CreateEventRequest == true)
            {
                CreateEventRequest cER = (CreateEventRequest) request;
                enumAnswer = eventsManager.createEvent(cER.getEventName(), cER.getUserEmail(), cER.getParticipants(), cER.getExpenses());
            }
            else if(request instanceof DeleteEventRequest == true)
            {
                DeleteEventRequest dER = (DeleteEventRequest) request;
                enumAnswer = eventsManager.deleteEvent(dER.getEventName(), dER.getEmail());
            }
            else if(request instanceof EditEventRequest == true)
            {
                EditEventRequest eER = (EditEventRequest) request;
                enumAnswer = eventsManager.editEvent(eER.getOldName(), eER.getNewName(), eER.getEmail(), eER.getParticipants(), eER.getExpenses());
            }
            else if(request instanceof GetEventsFromUserRequest == true)
            {
                GetEventsFromUserRequest gEFUR = (GetEventsFromUserRequest) request;
                ArrayList<Event> eventsAnswer = eventsManager.getEventsFromUser(gEFUR.getEmail());
                oOS.writeUnshared(new Integer(eventsAnswer.size()));
                oOS.flush();
                for(Event event : eventsAnswer){
                    writeAnswerInJson(event);
                }

                System.out.println("GET_EVENTS_REQUEST");
                return;
            }
            else if(request instanceof LoginRequest == true)
            {
                LoginRequest lR = (LoginRequest) request;
                enumAnswer = eventsManager.loginUser(lR.getEmail(), lR.getPassword());
            }
            else if(request instanceof RegisterRequest == true)
            {
                RegisterRequest rR = (RegisterRequest) request;
                enumAnswer = eventsManager.registerUser(rR.getEmail(), rR.getPassword(), rR.getFirstName(), rR.getLastName());
            }
            else if(request instanceof PublishEventRequest == true)
            {
                PublishEventRequest pER = (PublishEventRequest) request;
                enumAnswer = eventsManager.setEventAsPublished(pER.getName(), pER.getEmail());
                if(enumAnswer == EnumActionResult.EVENT_IS_PUBLISHED)
                {
                    oOS.writeUnshared(new Boolean(true));
                    oOS.flush();
                }
                else
                {
                    oOS.writeUnshared(new Boolean(false));
                    oOS.flush();
                }

                return;
            }
            else if(request instanceof MarkUserAsHavePaidRequest == true)
            {
                MarkUserAsHavePaidRequest mUAHPR = (MarkUserAsHavePaidRequest) request;
                Boolean bool = eventsManager.markUserAsHavePaid(mUAHPR.getEventName(), mUAHPR.getUser());
                System.out.println("MARK_USER_EVENT_REQUEST with answer " + bool);
                oOS.writeUnshared(bool);
                oOS.flush();
                return;
            }
            else if(request instanceof LogOutRequest == true)
            {
                LogOutRequest lOR = (LogOutRequest) request;
                eventsManager.logoutUser(lOR.getEmail());
                return;
            }
            else if(request instanceof RecoverPasswordRequest == true)
            {
                RecoverPasswordRequest rPR = (RecoverPasswordRequest) request;
                eventsManager.recoverPassword(rPR.getEmail());
                return;
            }
            else if(request instanceof VerifyUserExistsRequest == true)
            {
                VerifyUserExistsRequest vUER = (VerifyUserExistsRequest) request;
                enumAnswer = eventsManager.userExists(vUER.getEmail());
            }
            else if(request instanceof ConnectionRequest == true)
            {
                return;
            }
    
            System.out.println(enumAnswer.getValue());
            writeAnswerInJson(enumAnswer.getValue());

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Unable to take client request!");
            System.err.println(e.getStackTrace());
        }/* finally{
            try {
                socket.close();
            } catch (IOException e) {
                System.err.println("Unable to close socket after taking client's request.");
                System.err.println(e.getStackTrace());
            }
        } */
        
                

    }






    private Request deserializeRequest(String stringRequest) throws ClassNotFoundException
    {
        Scanner scanner = new Scanner(stringRequest);

        String requestType = scanner.nextLine();

        String[] array = requestType.split("\\.");

        String classeMinada = "server.events_manager.event_manager_data.requests.";

        requestType = classeMinada + array[array.length-1];

        String jsonRepresentation = scanner.nextLine();

        Class<?> requestClass = Class.forName(requestType);

        Request request = (Request)new Gson().fromJson(jsonRepresentation, requestClass);

        scanner.close();

        return request;
    }






    





    /**
     * This method prepares receives an object with the answer to be sent to the client
     * and writes it to the output stream of the socket
     * 
     * @param Object The answer to be sent to the client
    */
    private void writeAnswerInJson(Object answer) throws IOException
    {
        oOS.writeUnshared(new Gson().toJson(answer));
        oOS.flush();
    }


}