package server.events_manager.event_manager_data.requests;

public class VerifyUserExistsRequest implements Request
{
    private String email;

    public VerifyUserExistsRequest(String email)
    {
        this.email = email;
    }

    public String getEmail(){ return email; }
}