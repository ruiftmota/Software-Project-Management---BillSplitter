package server.events_manager;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import server.events_manager.event_manager_data.EventsManagerData;
import server.events_manager.event_manager_data.events_information.EnumActionResult;
import server.events_manager.event_manager_data.events_information.Event;
import server.events_manager.event_manager_data.events_information.Expense;
import server.events_manager.event_manager_data.events_information.User;

@RunWith(Parameterized.class)
public class TestEventsManagerData {

    private String email;
    private String password;
    private String firstName;
    private String lastName;

    private EventsManagerData eventsManagerData;

    // @BeforeClass
    // public static void beforeClass() {

    // }

    @Parameters(name = "{index}] ({0})")
    public static Collection<Object[]> UsersData() {
        Object[][] data = new Object[][] { { "armindo@email.com", "armindo!30.", "armando", "armindo" },
                { "jacinto@email.com", "jaci!ros", "jacinto", "queiros" },
                { "alfredo.pinto@email.com", "alfredo.2@", "Alfredo", "Pinto" } };
        return Arrays.asList(data);
    }

    public TestEventsManagerData(String email, String password, String firstName, String lastName) {

        this.email = email;
        this.password = password;
        this.firstName = firstName;
        this.firstName = firstName;

    }

    @Before
    public void before() {
        eventsManagerData = new EventsManagerData();
    }

    @Test
    public void registerUnExistantUserTest() {
        assertEquals(EnumActionResult.REGISTER_SUCCESSFULL,
                eventsManagerData.registerUser(email, password, firstName, lastName));
    }

    @Test
    public void registerExistantUserTest() {
        eventsManagerData.registerUser(email, "password", "firstName", "lastName");

        assertEquals(EnumActionResult.REGISTER_REFUSED,
                eventsManagerData.registerUser(email, password, firstName, lastName));
    }

    @Test
    public void loginUnRegisteredUserTest() {
        assertEquals(EnumActionResult.UNEXISTANT_USER, eventsManagerData.loginUser(email, password));
    }

    @Test
    public void loginRegisteredUser_alreadyLoggedInTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        eventsManagerData.loginUser(email, password);

        assertEquals(EnumActionResult.USER_ALREADY_LOGGED_IN, eventsManagerData.loginUser(email, password));
    }

    @Test
    public void loginRegisteredUser_InvalidPasswordTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);

        String wrongPassword = "password";
        assertEquals(EnumActionResult.LOGIN_REFUSED, eventsManagerData.loginUser(email, wrongPassword));
    }

    @Test
    public void loginRegisteredUserTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);

        assertEquals(EnumActionResult.LOGIN_SUCCESSFULL, eventsManagerData.loginUser(email, password));
    }

    @Test
    public void userExistsTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);

        assertEquals(EnumActionResult.USER_EXISTS, eventsManagerData.userExists(email));
    }

    @Test
    public void unExistantUserTest() {
        assertEquals(EnumActionResult.UNEXISTANT_USER, eventsManagerData.userExists(email));
    }

    @Test
    public void createEventTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        assertEquals(EnumActionResult.EVENT_CREATION_SUCCESSFULL,
                eventsManagerData.createEvent("eventName", email, users, expenses));

    }

    @Test
    public void createEvent_UnExistantUserTest() {
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        assertEquals(EnumActionResult.UNEXISTANT_USER,
                eventsManagerData.createEvent("eventName", "test@email.com", users, expenses));

    }

    @Test
    public void createEvent_alreadyExistTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, users, expenses);

        assertEquals(EnumActionResult.EVENT_ALREADY_EXISTS,
                eventsManagerData.createEvent("eventName", email, users, expenses));

    }

    @Test
    public void editUnexistantEventTest() {
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();

        assertEquals(EnumActionResult.UNEXISTANT_EVENT,
                eventsManagerData.editEvent("eventName", "newName", email, users, expenses));

    }

    @Test
    public void editEvent_NotAdminTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, users, expenses);

        assertEquals(EnumActionResult.NOT_ADMIN,
                eventsManagerData.editEvent("eventName", "newName", "notAdmin@email.com", users, expenses));

    }

    @Test
    public void editPublishedEventTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, users, expenses);
        eventsManagerData.setEventAsPublished("eventName", email);

        assertEquals(EnumActionResult.EVENT_IS_PUBLISHED,
                eventsManagerData.editEvent("eventName", "newName", email, users, expenses));
    }

    @Test
    public void editEventTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, users, expenses);

        assertEquals(EnumActionResult.EDITION_SUCCESSFULL,
                eventsManagerData.editEvent("eventName", "newName", email, users, expenses));
    }

    @Test
    public void deleteUnExistantEventTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);

        assertEquals(EnumActionResult.UNEXISTANT_EVENT, eventsManagerData.deleteEvent("eventName", email));
    }

    @Test
    public void deleteEvent_NotAdminTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, users, expenses);

        assertEquals(EnumActionResult.NOT_ADMIN, eventsManagerData.deleteEvent("eventName", "notAdmin@email.com"));
    }

    @Test
    public void deleteEventTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, users, expenses);

        assertEquals(EnumActionResult.DELETED_SUCCESSFULLY, eventsManagerData.deleteEvent("eventName", email));
    }

    

    @Test
    public void getEventsFromUserTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        eventsManagerData.registerUser("emailTest@email.com", "password", "firstName", "lastName");
        ArrayList<Expense> expenses = new ArrayList<Expense>();

        ArrayList<String> usersStrings = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, usersStrings, expenses);
        usersStrings.add((email));
        eventsManagerData.createEvent("eventName2", "emailTest@email.com", usersStrings, expenses);

        ArrayList<User> users = new ArrayList<User>();
        users.add(new User(email, password, firstName, lastName));
        users.add(new User("emailTest@email.com", "password", "firstName", "lastName"));

        ArrayList<Event> userEvents = new ArrayList<Event>();
        userEvents.add(new Event("eventName", users.get(0), users, expenses));
        userEvents.add(new Event("eventName", users.get(1), users, expenses));
        assertEquals(userEvents, eventsManagerData.getEventsFromUser(email));
    }

    @Test
    public void setUnExistantEventAsPublishedTest() {
        assertEquals(EnumActionResult.UNEXISTANT_EVENT, eventsManagerData.setEventAsPublished("eventName", email));
    }

    @Test
    public void setEventAsPublished_NotAdminTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, users, expenses);
        assertEquals(EnumActionResult.NOT_ADMIN, eventsManagerData.setEventAsPublished("eventName", "admin@email.com"));
    }

    @Test
    public void setEventAsPublishedTest() {
        eventsManagerData.registerUser(email, password, firstName, lastName);
        ArrayList<Expense> expenses = new ArrayList<Expense>();
        ArrayList<String> users = new ArrayList<String>();
        eventsManagerData.createEvent("eventName", email, users, expenses);
        assertEquals(EnumActionResult.EVENT_IS_PUBLISHED, eventsManagerData.setEventAsPublished("eventName", email));
    }

    // @After
    // public void after() {
    // System.out.println("After Test Case");
    // }

    // @AfterClass
    // public static void afterClass() {
    // System.out.println("After Class");
    // }
}