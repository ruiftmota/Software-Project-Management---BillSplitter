package server.events_manager.event_manager_data.requests;

public class ConnectionRequest implements Request
{
        
}