package server.events_manager.event_manager_data.requests;



public class GetEventsFromUserRequest implements Request
{
    private String email;

    public GetEventsFromUserRequest(String email) 
    {
        this.email = email;
    }

    public String getEmail(){ return email; }

    
}