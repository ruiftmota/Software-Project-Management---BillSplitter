package server.events_manager.event_manager_data.requests;

public class MarkUserAsHavePaidRequest implements Request
{
    private String eventName;
    private String userEmail;

    public MarkUserAsHavePaidRequest(String eventName, String userEmail)
    {
        this.eventName = eventName;
        this.userEmail = userEmail;
    }

    public String getEventName()
    {
        return eventName;
    }

    public String getUser()
    {
        return userEmail;
    }
}