package server.events_manager.event_manager_data.requests;

public class RecoverPasswordRequest implements Request
{
    String email;

    public RecoverPasswordRequest(String email) 
    {
        this.email = email;
    }

    public String getEmail() { return email; }
    
}