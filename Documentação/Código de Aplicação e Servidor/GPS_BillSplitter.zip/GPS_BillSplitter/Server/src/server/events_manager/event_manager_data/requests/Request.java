package server.events_manager.event_manager_data.requests;



public interface Request { }