package server.events_manager.event_manager_data.requests;



public class LogOutRequest implements Request
{
    String email;

    public LogOutRequest(String email) 
    {
        this.email = email;
    }

    public String getEmail() 
    {
        return email;
    }
    
}