package server.events_manager.event_manager_data.requests;

public class DeleteEventRequest implements Request
{
    private String email;
    private String eventName;

    public DeleteEventRequest(String email, String eventName) 
    {
        this.email = email;
        this.eventName = eventName;
    }

    public String getEmail() { return email; }

    public String getEventName() { return eventName; }
    
}