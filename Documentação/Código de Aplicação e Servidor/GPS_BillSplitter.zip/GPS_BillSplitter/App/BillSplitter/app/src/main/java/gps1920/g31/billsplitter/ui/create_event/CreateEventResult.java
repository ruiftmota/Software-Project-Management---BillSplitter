package gps1920.g31.billsplitter.ui.create_event;

import androidx.annotation.Nullable;

import gps1920.g31.billsplitter.data.server_interface.events_information.EnumActionResult;

public class CreateEventResult {
    @Nullable
    private EnumActionResult sucess;

    CreateEventResult(EnumActionResult sucess) {
        this.sucess = sucess;
    }

    EnumActionResult getSucess()
    {
        return sucess;
    }
}