package gps1920.g31.billsplitter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Objects;

import gps1920.g31.billsplitter.data.EventRepository;
import gps1920.g31.billsplitter.data.model.ListViewModel;
import gps1920.g31.billsplitter.data.model.LoggedInUser;
import gps1920.g31.billsplitter.data.server_interface.ServerInterface;
import gps1920.g31.billsplitter.data.server_interface.events_information.EnumActionResult;
import gps1920.g31.billsplitter.data.server_interface.events_information.Event;
import gps1920.g31.billsplitter.ui.MyDialog;
import gps1920.g31.billsplitter.ui.create_event.CreateEventActivity;
import gps1920.g31.billsplitter.ui.edit_event.EditEventActivity;
import gps1920.g31.billsplitter.ui.login.LoginActivity;
import gps1920.g31.billsplitter.ui.show_event.ShowEventActivity;


/**
 * <h1>List of all events in which the user participates!</h1>
 * This class shows all events in which the user is integrated
 *
 * @author  Paulo Dias
 * @version 1.0
 * @since   27-09-2019
 */
//TODO Thread para delete
    //TODO Thread para publish
    //TODO Thread para setPaid
public class MainActivity extends AppCompatActivity {
    ListViewModel listViewModel;
    RecyclerView recyclerView;
    TextView tvEmptyList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(LoggedInUser.getUserId() == null)
        {
            Intent intent = new Intent(this, PlanoDeContigenciaActivity.class);
            startActivity(intent);
            finish();
        }


        //Inicio da apresentação da lista de eventos
        tvEmptyList = findViewById(R.id.tvEmptyList);
        recyclerView = findViewById(R.id.rvList);
        listViewModel = ViewModelProviders.of(this).get(ListViewModel.class);

        if (listViewModel.getSize()==0)
        {
            tvEmptyList.setVisibility(View.VISIBLE);
        }
        else
            tvEmptyList.setVisibility(View.INVISIBLE);

        // Criação de um novo evento
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), CreateEventActivity.class);
                startActivityForResult(intent, 1);

            }
        });

        FloatingActionButton fabRefresh = findViewById(R.id.fabRefresh);
        fabRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateListFromServer();
            }
        });


        //Criação da lista de eventos
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false));
        recyclerView.setAdapter(new MyRVAdapter());
        listViewModel.setObserver(this, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean aBoolean) {
                recyclerView.requestLayout();
            }
        });

        //Pedir lista ao iniciar
        updateListFromServer();
    }

    private class UpdateListTask extends AsyncTask<Integer, Integer, ArrayList<EventRepository>>
    {

        @Override
        protected ArrayList<EventRepository> doInBackground(Integer... integers) {
            ArrayList<Event> list;
            ArrayList<EventRepository> eventList = new ArrayList<>();

            list = ServerInterface.getEventsFromUser(LoggedInUser.getUserId());
            if (list != null)
            {
                EventRepository eventRepository;
                for (Event ev : list)
                {
                    eventRepository = new EventRepository(ev);
                    eventList.add(eventRepository);
                }
            }
            return eventList;
        }

        @Override
        protected void onPostExecute(ArrayList<EventRepository> eventRepositories) {
            listViewModel.setList(eventRepositories);
            recyclerView.getAdapter().notifyDataSetChanged();
        }
    }

    public void updateListFromServer()
    {
        UpdateListTask updateListTask = new UpdateListTask();
        updateListTask.execute();
    }

    //Método para abrir uma janela de dialogo
    public void openDialog (int title, int description, int position) {
        MyDialog dialog = new MyDialog(title, description, position, "main");
        dialog.show(getSupportFragmentManager(),"dialogAlert");
    }

    //Método para eliminar um evento da lista
    public void doDeleteClick(int position) {
        //listViewModel.removeItem(position);
        //recyclerView.getAdapter().notifyDataSetChanged();
        DeleteTask deleteTask = new DeleteTask();
        deleteTask.execute(LoggedInUser.getUserId(), listViewModel.getItem(position).getTitle());

    }

    private class DeleteTask extends AsyncTask<String, Integer, EnumActionResult>
    {

        @Override
        protected EnumActionResult doInBackground(String... strings) {
            EnumActionResult sucess = ServerInterface.deleteEvent(strings[0], strings[1]);
            return sucess;
        }

        @Override
        protected void onPostExecute(EnumActionResult enumActionResult) {
            updateListFromServer();
        }
    }

    //Método para publicar um evento da lista
    public void doPublishClick(int position) {
        listViewModel.setPublish(position);
        recyclerView.getAdapter().notifyDataSetChanged();
        PublishTask publishTask = new PublishTask();
        publishTask.execute(LoggedInUser.getUserId(), listViewModel.getItem(position).getTitle());
    }

    private class PublishTask extends AsyncTask<String, Integer, Boolean>
    {

        @Override
        protected Boolean doInBackground(String... strings) {
            return ServerInterface.setPublishEvent(strings[0], strings[1]);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            updateListFromServer();
        }
    }

    //Adaptador da RecyclerView para a lista de eventos
    class MyRVAdapter extends RecyclerView.Adapter<MyRVAdapter.MyViewHolder>{
        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View layout = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.cardview_list_event,parent,false);

            MyViewHolder mvh = new MyViewHolder(layout);
            return mvh;
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

            EventRepository event = listViewModel.getItem(position);
            boolean creator = true;
            if (!event.getCreator().getEmail().equalsIgnoreCase(LoggedInUser.getUserId()))
                creator = false;

            holder.updateUI(event.getTitle(),
                    event.getValue(),
                    event.getNumberOfParticipants(),
                    creator);
        }

        @Override
        public int getItemCount() {
            return listViewModel.getSize();
        }

        class MyViewHolder extends RecyclerView.ViewHolder {

            TextView tvTitle, tvMessage, tvUsersNumber, tvLock;
            ImageButton btnDelete, btnEdit, btnPublish;
            public MyViewHolder(@NonNull View itemView){
                super(itemView);
                tvTitle = itemView.findViewById(R.id.tvTitle);
                tvMessage = itemView.findViewById(R.id.tvValue);
                tvUsersNumber = itemView.findViewById(R.id.tvTotalParticipntsCardView);
                tvLock = itemView.findViewById(R.id.tvLockList);
                btnEdit = itemView.findViewById(R.id.btnEdit);
                btnDelete = itemView.findViewById(R.id.btnDelete);
                btnPublish = itemView.findViewById(R.id.btnPublishList);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getApplicationContext(), ShowEventActivity.class);
                        intent.putExtra("item", listViewModel.getItem(getAdapterPosition()));
                        intent.putExtra("position", getAdapterPosition());
                        startActivityForResult(intent, 3);
                    }
                });


                btnDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openDialog(R.string.dialog_delete_title, R.string.dialog_description, getAdapterPosition());

                    }
                });

                btnPublish.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openDialog(R.string.dialog_publish_title, R.string.dialog_description, getAdapterPosition());
                    }
                });

                btnEdit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getApplicationContext(), EditEventActivity.class);
                        intent.putExtra("item", listViewModel.getItem(getAdapterPosition()));
                        intent.putExtra("position", getAdapterPosition());
                        startActivityForResult(intent, 2);
                    }
                });
            }

            //Método para atualizar os itens da Recycler View
            public  void updateUI(String t, double m, double nUsers, boolean creator){

                if (!creator)
                {
                    btnDelete.setVisibility(View.GONE);
                    btnEdit.setVisibility(View.GONE);
                    tvLock.setVisibility(View.GONE);
                    btnPublish.setVisibility(View.GONE);
                    String strAux = String.valueOf(m/nUsers) + "0000";
                    strAux = strAux.substring(0, strAux.indexOf(".") +3);
                    tvMessage.setText("Valor a pagar:\n" + strAux + "€");
                }
                else if(listViewModel.getItem(getAdapterPosition()).getPublish())
                {
                    btnEdit.setVisibility(View.GONE);
                    tvLock.setVisibility(View.GONE);
                    btnPublish.setVisibility(View.GONE);
                    btnDelete.setVisibility(View.VISIBLE);
                    tvMessage.setText("Despesa:\n" + m + "€");

                }
                else
                {
                    btnEdit.setVisibility(View.VISIBLE);
                    tvLock.setVisibility(View.VISIBLE);
                    btnPublish.setVisibility(View.VISIBLE);
                    btnDelete.setVisibility(View.VISIBLE);
                    tvMessage.setText("Despesa:\n" + m + "€");
                }




                tvTitle.setText(t);
                tvUsersNumber.setText((int)nUsers + "\nPessoas");
                tvEmptyList.setVisibility(View.INVISIBLE);

            }

        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1)
        {
            if (resultCode == RESULT_OK)
            {
                updateListFromServer();
            }
            else
                Toast.makeText(getApplicationContext(), "Não foi possível criar o evento", Toast.LENGTH_SHORT).show();
        }

        if (requestCode == 2) //EDIT
        {
            if (resultCode == RESULT_OK)
            {
                /*
                assert data != null;
                int position = data.getIntExtra("position", -1);
                doDeleteClick(position);

                 */
                updateListFromServer();
            }
            else
                Toast.makeText(getApplicationContext(), "Não foi possível editar o evento", Toast.LENGTH_SHORT).show();
        }
        if (requestCode == 3)
        {
            if (resultCode == RESULT_OK)
            {
                updateListFromServer();
            }
            else if (resultCode == 4)
            {
                Toast.makeText(getApplicationContext(), "Não foi possível editar o evento", Toast.LENGTH_SHORT).show();
                updateListFromServer();
            }
            else if (resultCode == 5) //Edit do show event
            {
                /*
                assert data != null;
                int position = data.getIntExtra("position", -1);
                doDeleteClick(position);

                 */
                updateListFromServer();
            }
            else if(resultCode == 3)
            {
                assert data != null;
                int position = data.getIntExtra("position", -1);
                doDeleteClick(position);
            }
            else
                updateListFromServer();

        }
    }

}
