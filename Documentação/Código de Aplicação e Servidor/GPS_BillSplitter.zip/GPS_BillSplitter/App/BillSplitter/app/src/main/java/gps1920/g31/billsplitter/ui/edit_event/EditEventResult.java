package gps1920.g31.billsplitter.ui.edit_event;

import androidx.annotation.Nullable;

import gps1920.g31.billsplitter.data.server_interface.events_information.EnumActionResult;

public class EditEventResult {
    @Nullable
    private EnumActionResult sucess;

    EditEventResult(EnumActionResult sucess) {
        this.sucess = sucess;
    }

    EnumActionResult getSucess()
    {
        return sucess;
    }
}
