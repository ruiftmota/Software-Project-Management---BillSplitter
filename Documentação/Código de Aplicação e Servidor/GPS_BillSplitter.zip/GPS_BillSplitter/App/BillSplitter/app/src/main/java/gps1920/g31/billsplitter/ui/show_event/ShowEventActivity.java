package gps1920.g31.billsplitter.ui.show_event;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Objects;

import gps1920.g31.billsplitter.R;
import gps1920.g31.billsplitter.data.EventRepository;
import gps1920.g31.billsplitter.data.ExpenseRepository;
import gps1920.g31.billsplitter.data.ParticipantsRepository;
import gps1920.g31.billsplitter.data.model.ListExpensesViewModel;
import gps1920.g31.billsplitter.data.model.ListParticipantsViewModel;
import gps1920.g31.billsplitter.data.model.LoggedInUser;
import gps1920.g31.billsplitter.data.server_interface.ServerInterface;
import gps1920.g31.billsplitter.ui.MyDialog;
import gps1920.g31.billsplitter.ui.edit_event.EditEventActivity;

public class ShowEventActivity extends AppCompatActivity {
    EventRepository event;
    TextView tvTitle;
    TextView tvTotalParticipants;
    TextView tvExpense;
    CheckBox cbPaid;
    TextView tvLock;
    ImageButton btnPublish;
    ImageButton btnDelete;
    ImageButton btnEdit;
    boolean eventEdited;
    int position;
    boolean published;

    RecyclerView rvExpenses;
    ListExpensesViewModel listExpensesViewModel;

    RecyclerView rvParticipants;
    ListParticipantsViewModel listParticipantsViewModel;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_event);
        eventEdited = false;
        Intent intent = getIntent();
        event = intent.getParcelableExtra("item");
        position = intent.getIntExtra("position", -1);
        published = event.getPublish();


        //Apresentar titulo do evento
        tvTitle = findViewById(R.id.tvEventTitle);
        tvTitle.setText(event.getTitle());

        //Apresentar numero total de participantes, incluindo o criador
        tvTotalParticipants = findViewById(R.id.tvTotalParticipants);
        String str = event.getNumberOfParticipants() + "\nPessoas";
        tvTotalParticipants.setText(str);

        //Apresentar o total da despesa em €
        tvExpense = findViewById(R.id.tvTotalExpense);


        cbPaid = findViewById(R.id.checkBoxPaid);
        tvLock = findViewById(R.id.tvLock);
        btnPublish = findViewById(R.id.btnPublish);
        btnDelete = findViewById(R.id.btnDeleteEvent);
        btnEdit = findViewById(R.id.btnEditEvent);


        //Apresentar dados exclusivos do criador:
        if(event.getCreator().getEmail().equalsIgnoreCase(LoggedInUser.getUserId()))
        {
            cbPaid.setVisibility(View.GONE);
            String strTotalExpense = "Despesa:\n" + event.getValue() + "€";
            tvExpense.setText(strTotalExpense);
        }
        else
        {
            double individualExpense = event.getValue() / (double)event.getNumberOfParticipants();
            String strAux = individualExpense + "0000";
            strAux = strAux.substring(0, strAux.indexOf(".") +3);
            String strIndividualExpense = "Valor a pagar:\n" + strAux + "€";
            tvExpense.setText(strIndividualExpense);
            tvLock.setVisibility(View.GONE);
            btnPublish.setVisibility(View.GONE);
            btnEdit.setVisibility(View.GONE);
            btnDelete.setVisibility(View.GONE);
            if (!event.getPublish())
                cbPaid.setVisibility(View.GONE);
            for (ParticipantsRepository part : event.getParticipants())
            {
                if (part.getEmail().equalsIgnoreCase(LoggedInUser.getUserId()))
                {
                    cbPaid.setChecked(part.isPago());
                }
            }
            if (cbPaid.isChecked())
                cbPaid.setEnabled(false);
            cbPaid.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cbPaid.setChecked(false);
                    openDialog(R.string.dialog_pay_title, R.string.dialog_description, position);
                }
            });
        }
        if (published)
        {
            tvLock.setVisibility(View.GONE);
            btnPublish.setVisibility(View.GONE);
            btnEdit.setVisibility(View.GONE);
        }


        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(R.string.dialog_delete_title, R.string.dialog_description, position);
            }
        });

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EditEventActivity.class);
                intent.putExtra("item", event);
                startActivityForResult(intent, 4);
            }
        });

        btnPublish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(R.string.dialog_publish_title, R.string.dialog_description, position);
            }
        });

        rvExpenses = findViewById(R.id.rvShowExpenses);
        listExpensesViewModel = ViewModelProviders.of(this).get(ListExpensesViewModel.class);

        rvExpenses.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        rvExpenses.setAdapter(new ExpenseAdapter());

        listExpensesViewModel.setObserver(this, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean aBoolean) {
                rvExpenses.requestLayout();
            }
        });


        for (ExpenseRepository exR: event.getExpenses())
        {
            listExpensesViewModel.addItem(exR.getTitle(),exR.getValue());
        }

        listParticipantsViewModel = ViewModelProviders.of(this).get(ListParticipantsViewModel.class);

        for (ParticipantsRepository partR: event.getParticipants())
        {
            listParticipantsViewModel.addItem(partR);
        }


    }
    public void openDialog (int title, int description, int position) {
        MyDialog dialog = new MyDialog(title, description, position, "show event");
        dialog.show(getSupportFragmentManager(),"dialogAlert");
    }

    public void doDeleteClick(int position) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("position", position);
        setResult(3, resultIntent);
        finish();
    }

    public void doPayClick(){
        //TODO: Enviar pedido de setPaid
        PayTask payTask = new PayTask();
        payTask.execute(event.getTitle(), LoggedInUser.getUserId());
    }

    private class PayTask extends AsyncTask<String, Integer, Boolean>
    {

        @Override
        protected Boolean doInBackground(String... strings) {
            return ServerInterface.markUserAsHavePaid(strings[0], strings[1]);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if (aBoolean)
            {
                cbPaid.setChecked(true);
                cbPaid.setEnabled(false);
                for (int i = 0; i < listParticipantsViewModel.getSize(); i++)
                {
                    if (listParticipantsViewModel.getItem(i).getEmail().equalsIgnoreCase(LoggedInUser.getUserId()))
                        listParticipantsViewModel.getItem(i).setPago(true);
                }
            }
            else
                Toast.makeText(ShowEventActivity.this, "Erro ao marcar como pago.\nTente novamente", Toast.LENGTH_SHORT).show();
        }
    }

    public void doPublishClick() {
        tvLock.setVisibility(View.GONE);
        btnPublish.setVisibility(View.GONE);
        btnEdit.setVisibility(View.GONE);
        event.setPublish();
        eventEdited = true;
        Toast.makeText(getApplicationContext(), "Publicado", Toast.LENGTH_SHORT).show();
        PublishTask publishTask = new PublishTask();
        publishTask.execute(LoggedInUser.getUserId(), event.getTitle());
    }

    private class PublishTask extends AsyncTask<String, Integer, Boolean>
    {

        @Override
        protected Boolean doInBackground(String... strings) {
            return ServerInterface.setPublishEvent(strings[0], strings[1]);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {

        }
    }

    public void onParticipants(View view) {
        ParticipantsDialog pDialog = new ParticipantsDialog(listParticipantsViewModel, event.getCreator().getEmail());
        pDialog.show(getSupportFragmentManager(), "participantsDialog");
    }



    class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>{

        @NonNull
        @Override
        public ExpenseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_list_show_expenses, parent, false);

            ExpenseViewHolder evh = new ExpenseViewHolder(layout);
            return evh;
        }

        @Override
        public void onBindViewHolder(@NonNull ExpenseViewHolder holder, int position) {
            ExpenseRepository expense = listExpensesViewModel.getItem(position);

            holder.updateUI(expense.getTitle(),expense.getValue() + "€", String.valueOf(position + 1));
        }

        @Override
        public int getItemCount() {
            return listExpensesViewModel.getSize();
        }

        class ExpenseViewHolder extends RecyclerView.ViewHolder{
            TextView tvName, tvValue, tvNumber;

            public ExpenseViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvExpenseName);
                tvNumber = itemView.findViewById(R.id.tvExpenseNumber);
                tvValue = itemView.findViewById(R.id.tvExpenseValue);
            }

            public void updateUI(String name, String value, String number){
                 tvName.setText(name);
                 tvValue.setText(value);
                 tvNumber.setText(number);
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 4)
        {
            Intent resultIntent = new Intent();
            if (resultCode == RESULT_OK)
            {
                resultIntent.putExtra("position", position);
                setResult(5, resultIntent);
            }
            else
                setResult(4, resultIntent);
            finish();
        }
    }


}
