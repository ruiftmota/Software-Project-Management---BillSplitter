package gps1920.g31.billsplitter.data.server_interface.requests;

public class MarkUserAsHavePaidRequest implements Request
{
    private String eventName;
    private String userEmail;

    public MarkUserAsHavePaidRequest(String eventName, String userEmail)
    {
        this.eventName = eventName;
        this.userEmail = userEmail;
    }

    public String getEventName()
    {
        return eventName;
    }

    public String getUser()
    {
        return userEmail;
    }
}