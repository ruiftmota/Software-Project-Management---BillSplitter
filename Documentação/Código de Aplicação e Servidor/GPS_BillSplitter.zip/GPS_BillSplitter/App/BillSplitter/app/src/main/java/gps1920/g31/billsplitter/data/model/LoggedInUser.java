package gps1920.g31.billsplitter.data.model;

/**
 * Data class that captures user information for logged in users retrieved from LoginRepository
 */
public class LoggedInUser {

    private static String userId;
    private static String name;
    private static String surname;
    private static String displayName;

    public static void setUser(String userId, String firstName, String lastName) {
        LoggedInUser.userId = userId;
        name = firstName;
        surname = lastName;
        displayName = firstName + " " + lastName;
    }

    public static String getUserId() {
        return userId;
    }

    public static String getDisplayName() {
        return displayName;
    }

    public static String getName() {
        return name;
    }

    public static String getSurname() {
        return surname;
    }

    public static void logOut()
    {
        LoggedInUser.userId = null;
        name = null;
        surname = null;
        displayName = null;
    }
}
