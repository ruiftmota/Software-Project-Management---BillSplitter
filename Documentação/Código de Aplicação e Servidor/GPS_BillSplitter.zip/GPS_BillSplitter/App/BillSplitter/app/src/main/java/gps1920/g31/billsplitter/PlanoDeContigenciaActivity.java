package gps1920.g31.billsplitter;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import gps1920.g31.billsplitter.data.server_interface.ServerInterface;
import gps1920.g31.billsplitter.ui.login.LoginActivity;

public class PlanoDeContigenciaActivity extends AppCompatActivity {
    private EditText etIP;
    private Button btnConnect;
    private ProgressBar loading;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pede_ip_activity);
        etIP = findViewById(R.id.editTextIP);
        btnConnect = findViewById(R.id.btnConnect);
        loading = findViewById(R.id.loadingSetIP);

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loading.setVisibility(View.VISIBLE);
                String ip = etIP.getText().toString();
                SetIPTask setIPTask = new SetIPTask();

                setIPTask.execute(ip);


            }
        });
    }

    private class SetIPTask extends AsyncTask<String, Integer, Boolean>
    {

        @Override
        protected Boolean doInBackground(String... strings) {
            return ServerInterface.setServerIP(strings[0]);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            loading.setVisibility(View.GONE);
            if(aBoolean)
            {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Falha na conexão com o servidor", Toast.LENGTH_SHORT).show();
            }
        }
    }



}
