package gps1920.g31.billsplitter.data.server_interface.requests;



public class LogOutRequest implements Request
{
    String email;

    public LogOutRequest(String email) 
    {
        this.email = email;
    }

    public String getEmail() 
    {
        return email;
    }
    
}