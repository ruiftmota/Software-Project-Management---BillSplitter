package gps1920.g31.billsplitter.data.server_interface.requests;



public interface Request { }