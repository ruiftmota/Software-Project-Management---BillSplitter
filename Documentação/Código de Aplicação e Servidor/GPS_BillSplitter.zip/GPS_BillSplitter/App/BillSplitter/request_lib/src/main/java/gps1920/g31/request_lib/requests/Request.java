package gps1920.g31.request_lib.requests;



public interface Request { }